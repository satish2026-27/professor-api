"""
Service layer that wraps your professor's .ipynb logic.

Migration plan from notebook -> FastAPI:

1) Extract pure functions from the .ipynb into regular .py modules.
2) Avoid global state where possible; if you must load a large model, do it once and cache.
3) Make every function take/return plain Python types or Pydantic models.
4) Ensure deterministic behavior for the same inputs.

This service exposes two sample functions:
- process(data): synchronous work
- process_heavy(data): 'heavy' work that you can later move to background jobs
"""
from typing import Any, Dict

class ProcessorService:
    def __init__(self):
        # Lazy-load models/resources here if needed.
        pass

    def process(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous processing entrypoint."""
        return {
            "ok": True,
            "summary": "Processed payload successfully",
            "received": payload,
        }

    def process_heavy(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Example 'heavier' work."""
        return {
            "ok": True,
            "note": "Heavy processing complete",
            "received": payload,
        }

processor = ProcessorService()
