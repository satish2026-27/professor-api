from fastapi import Header, HTTPException, status

from app.core.config import settings

def get_api_key(x_api_key: str | None = Header(default=None)):
    """Simple header-based API key auth."""
    if settings.API_KEY and x_api_key == settings.API_KEY:
        return True
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or missing X-API-Key",
    )
