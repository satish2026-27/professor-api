# FastAPI Exhaustive Starter (Professor Project)

A batteries-included FastAPI starter you can reuse for many projects. Remove what you don't need.

## Quick Start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env   # then edit values
./run_uvicorn.sh
# open http://localhost:8000/api/docs
```

### Auth
Send header: `X-API-Key: <value in .env>`

## Endpoints
- `GET /api/health`
- `GET /api/version`
- `POST /api/process` (protected)
- `POST /api/process/async` (protected)
- `POST /api/files/upload` (protected)

## Wrap your notebook
Move logic into functions in `app/services/processor.py` (or new module) and call them from routes.

## Frontend (React/Tailwind)
- Add your dev origin to `CORS_ORIGINS` in `.env`.
- Call endpoints with `fetch`/`axios`, including `X-API-Key`.
